# TODO

* suckless adblocking
* replace twitch() with proper gtk calls to make scrollbars reappear
* replace webkit with something sane
* add video player options
	* play in plugin
	* play in video player
	* call command with URI (quvi + cclive)

